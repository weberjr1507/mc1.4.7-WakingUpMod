package cpw.mods.fml.relauncher;

public class DummyDownloader implements IDownloadDisplay
{

    @Override
    public void resetProgress(int sizeGuess)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public void setPokeThread(Thread currentThread)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public void updateProgress(int fullLength)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean shouldStopIt()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void updateProgressString(String string, Object... data)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public Object makeDialog()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void makeHeadless()
    {
        // TODO Auto-generated method stub

    }

}
